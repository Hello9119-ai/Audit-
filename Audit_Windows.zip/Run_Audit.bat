@echo off
setlocal
cd /d "%~dp0"
title TPV Post-Assessment Forensic Laptop Audit

:: Automatically unblock Audit.exe if restricted by Windows 11 Smart App Control
powershell.exe -NoProfile -Command "Unblock-File -Path '.\Audit.exe' -ErrorAction SilentlyContinue" >nul 2>&1

if exist "%~dp0Audit.exe" (
    "%~dp0Audit.exe" %*
) else (
    echo [!] Error: Audit.exe not found in:
    echo     "%~dp0"
    echo Please make sure Audit.exe is in the same folder.
    pause
)
