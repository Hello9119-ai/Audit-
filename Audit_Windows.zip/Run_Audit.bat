@echo off
setlocal
title TPV Post-Assessment Forensic Laptop Audit
cd /d "%~dp0"

:: Handle Lookback Hours
set "HOURS=%~1"
if "%HOURS%"=="" (
    set /p "HOURS=Enter audit lookback window in hours [Press Enter for default: 2]: "
)
if "%HOURS%"=="" set "HOURS=2"

:: Check for Audit.ps1
if not exist "%~dp0Audit.ps1" (
    echo.
    echo [!] Error: Audit.ps1 not found in:
    echo     "%~dp0"
    echo Please make sure Run_Audit.bat and Audit.ps1 are in the same folder.
    echo.
    pause
    exit /b 1
)

:: Request Administrator Privileges if not already elevated
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [*] Requesting Administrator privileges for forensic audit...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/c \"\"%~f0\" %HOURS%\"' -Verb RunAs" 2>nul
    exit /b
)

:: Launch PowerShell Forensic Audit Script Directly
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Audit.ps1" -Hours %HOURS%

echo.
pause
