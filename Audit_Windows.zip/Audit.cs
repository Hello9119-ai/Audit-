using System;
using System.Diagnostics;
using System.IO;

namespace TPVAudit
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "TPV Post-Assessment Forensic Laptop Audit";
            string scriptDir = AppDomain.CurrentDomain.BaseDirectory;
            string psScript = Path.Combine(scriptDir, "Audit.ps1");

            if (!File.Exists(psScript))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n[!] Error: Audit.ps1 not found in:");
                Console.WriteLine("    " + scriptDir);
                Console.ResetColor();
                Console.WriteLine("Please make sure Audit.exe and Audit.ps1 are in the same folder.");
                Console.WriteLine("\nPress any key to exit...");
                Console.ReadKey();
                return;
            }

            string hours = args.Length > 0 ? args[0] : "";
            if (string.IsNullOrWhiteSpace(hours))
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("Enter audit lookback window in hours [Press Enter for default: 2]: ");
                Console.ResetColor();
                string input = Console.ReadLine();
                int hVal = 0;
                if (!string.IsNullOrWhiteSpace(input) && int.TryParse(input.Trim(), out hVal) && hVal > 0)
                {
                    hours = hVal.ToString();
                }
                else
                {
                    hours = "2";
                }
            }

            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = "powershell.exe";
            psi.Arguments = string.Format("-NoProfile -ExecutionPolicy Bypass -File \"{0}\" -Hours {1}", psScript, hours);
            psi.UseShellExecute = false;

            Process proc = Process.Start(psi);
            proc.WaitForExit();

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Audit complete. Press [Enter] to exit... ");
            Console.ResetColor();
            Console.ReadLine();
        }
    }
}
