param([int]$Hours = 2)
# ==============================================================================
# TPV Post-Assessment High-Confidence Forensic Laptop Audit (Windows)
# Focused STRICTLY on hard proof:
#   1. AI Question Solving & Chat (Gemini, ChatGPT, Claude, DeepSeek, etc.)
#   2. Active Screen Mirroring (Duplicate origin bounds, virtual display drivers, Miracast)
#   3. Remote Control & Screen Sharing (RDP, AnyDesk, TeamViewer, RustDesk, VNC)
#
# Consolidates repetitive URL visits into clear, distinct session windows.
# Ignores: VPNs, inactive background apps, leftover folders, and OS system noise.
# Nothing is saved or modified on disk.
# ==============================================================================

$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference    = 'SilentlyContinue'
$since      = (Get-Date).AddHours(-$Hours)
$isAdmin    = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

# Targeted High-Severity Signatures ONLY (Strictly AI, Remote, and Screen Mirroring)
$cats = [ordered]@{
  'REMOTE'   = 'anydesk|teamviewer|rustdesk|ultraviewer|ammyy|supremo|parsec|splashtop|logmein|tightvnc|realvnc|ultravnc|vncviewer|radmin|dwservice|getscreen|screenconnect|connectwise|nomachine|remotepc|rdpwrap|chrome ?remote|remoting_host|quickassist|quick assist|zoho ?assist|meshagent|meshcentral|todesk|sunlogin|airdroid|scrcpy|vysor|aweray|jump ?desktop|moonlight|sunshine'
  'MIRROR'   = 'miracast|wireless ?display|iddcx|iddsampledriver|amyuni|spacedesk|duet|luna ?display|displaylink|airserver|reflector|apowermirror|letsview|deskreen|virtualdisplay|dummydisplay'
  'AI-CHEAT' = 'cluely|interview ?coder|final ?round|lockedin|parakeet|leetcode ?wizard|chatgpt|openai|deepseek|perplexity|ollama|lm ?studio|gpt4all|claude|gemini|copilot|grok|blackbox|cursor|phind|poe|cody|tabnine|superwhisper|macwhisper|wispr|plaud|whisper|mistral|v0\.dev|bolt\.new|lovable'
}

# Browser Cheating & Clean AI Domains (Excludes login / oauth garbage)
$domains = '^https?://(gemini\.google\.com/app|share\.gemini\.google|chatgpt\.com|chat\.openai\.com|claude\.ai|deepseek\.com|chat\.deepseek\.com|perplexity\.ai|copilot\.microsoft\.com|grok\.com|blackbox\.ai|phind\.com|poe\.com|chegg\.com|coursehero\.com|brainly\.com|quizlet\.com|symbolab\.com|wolframalpha\.com|mathway\.com|cluely\.com|interviewcoder\.co|finalroundai\.com|lockedinai\.com|remotedesktop\.google\.com)'
$searchCheat = 'leetcode|hackerrank|interview.*coder|cheat|answer|solution|oa.*test|proctor|bypass'

function Is-GarbageUrl([string]$u) {
  if ($u -match 'accounts\.google\.com|gds\.google\.com|myaccount\.google\.com|policies\.google\.com|support\.google\.com|appleid\.apple\.com|login\.live\.com|login\.microsoftonline\.com|auth0\.openai\.com|/signin|/login|CheckCookie|SetSID|SetOSID|oauth|/auth\?|/auth/|challenge/pk|accountchooser|continue=|ServiceLogin|InteractiveLogin') {
    return $true
  }
  return $false
}

$script:proofList = New-Object System.Collections.Generic.List[object]
$script:historyTimeline = New-Object System.Collections.Generic.List[object]

function Record-Proof([string]$category, [string]$title, [string]$evidence, [string]$meaning) {
  $script:proofList.Add([pscustomobject]@{
    Category = $category
    Title    = $title
    Evidence = $evidence
    Meaning  = $meaning
  })
}

function Get-FriendlyTool([string]$url) {
  if ($url -match 'gemini\.google\.com') { return 'Google Gemini' }
  if ($url -match 'chatgpt\.com|chat\.openai\.com') { return 'ChatGPT (OpenAI)' }
  if ($url -match 'claude\.ai') { return 'Claude (Anthropic)' }
  if ($url -match 'deepseek\.com') { return 'DeepSeek AI' }
  if ($url -match 'perplexity\.ai') { return 'Perplexity AI' }
  if ($url -match 'copilot\.microsoft\.com') { return 'Microsoft Copilot' }
  if ($url -match 'grok\.com') { return 'Grok AI' }
  if ($url -match 'blackbox\.ai') { return 'Blackbox AI' }
  if ($url -match 'cluely\.com|interviewcoder|finalroundai|lockedinai') { return 'Interview Cheating Overlay' }
  if ($url -match 'chegg\.com|coursehero\.com|brainly\.com|quizlet\.com') { return 'Academic Answer Site' }
  if ($url -match 'remotedesktop\.google\.com|anydesk\.com|teamviewer\.com|rustdesk\.com|parsec\.app') { return 'Remote Desktop Web' }
  return 'AI Assistant / Solver'
}

function Tool-Of([string]$url) {
  return Get-FriendlyTool $url
}

function Safe-CopyFile([string]$src, [string]$dst) {
  try {
    [IO.File]::Copy($src, $dst, $true)
    return $true
  } catch {
    try {
      $inStream = [IO.File]::Open($src, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
      $outStream = [IO.File]::Create($dst)
      $inStream.CopyTo($outStream)
      $inStream.Close()
      $outStream.Close()
      return $true
    } catch {
      return $false
    }
  }
}

Clear-Host
Write-Host ''
Write-Host '  TPV POST-ASSESSMENT FORENSIC LAPTOP AUDIT' -ForegroundColor Cyan
Write-Host "  Laptop: $env:COMPUTERNAME   |   User: $env:USERNAME"
Write-Host "  Audit Look-back Window: Last $Hours hour(s) (since $since)   |   Time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Write-Host '  Filtering noise: VPNs, inactive apps, and system background tasks are suppressed.'
if (-not $isAdmin) {
  Write-Host '  [!] Warning: Not running as Administrator - Event Logs, Prefetch, and BAM checks are limited.' -ForegroundColor Yellow
}
Write-Host ''

# ==============================================================================
# 1. SCREEN MIRRORING, VIRTUAL ADAPTERS & DISPLAYS
# ==============================================================================
Write-Host '  [1/5] Checking Screen Mirroring, Virtual Display Adapters & Displays...' -ForegroundColor Cyan

Add-Type -AssemblyName System.Windows.Forms
$screens = [System.Windows.Forms.Screen]::AllScreens
$scrCount = $screens.Count

# Check for Duplicate Screen Coordinates (Active Clone / Mirror Mode)
$origins = $screens | Group-Object { "$($_.Bounds.X),$($_.Bounds.Y)" }
$mirrored = $origins | Where-Object { $_.Count -gt 1 }
if ($mirrored) {
  Record-Proof 'SCREEN MIRRORING' 'Active Screen Mirroring / Display Cloning Detected' `
    ("Multiple monitors share duplicate origin coordinates ($($mirrored.Name)) across {0} connected display(s)." -f $scrCount) `
    'PROCTOR VERIFICATION: Candidate screen is actively cloned/mirrored to a secondary display or external feed.'
}

# Check for Virtual Display Adapters and Indirect Displays (IddCx)
$pnpDisplays = Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | Where-Object {
  $_.Service -match 'IddCx|spacedesk|Duet|Amyuni|VirtualDisplay' -or
  $_.Name -match 'Virtual Display|IddSampleDriver|Amyuni|spacedesk|Duet|AirServer|Reflector|Deskreen'
}
foreach ($d in $pnpDisplays) {
  Record-Proof 'SCREEN MIRRORING' ("Virtual Display Driver Detected: {0}" -f $d.Name) `
    ("Driver Service: {0} | Device ID: {1}" -f $d.Service, $d.DeviceID) `
    'PROCTOR VERIFICATION: A software virtual display driver is installed, enabling off-screen streaming or mirroring.'
}

# Check for Hardware HDMI Capture Cards / USB Video Dongles (Hardware Screen Cloners)
$caps = Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | Where-Object {
  $_.Name -match 'Cam Link|HDMI to USB|Video Capture|Elgato|AverMedia|USB Capture'
}
foreach ($c in $caps) {
  Record-Proof 'HARDWARE CAPTURE' ("Hardware HDMI Video Capture Dongle: {0}" -f $c.Name) `
    ("Connected device: {0}" -f $c.Name) `
    'PROCTOR VERIFICATION: An HDMI capture card is plugged in, cloning video output to another computer.'
}

# Multi-monitor without mirror
if ($scrCount -gt 1 -and -not $mirrored) {
  Record-Proof 'MULTI-DISPLAY' ("Multiple Monitors Connected ({0} displays)" -f $scrCount) `
    ("Displays detected: {0}" -f (($screens | ForEach-Object { "$($_.Bounds.Width)x$($_.Bounds.Height)" }) -join ', ')) `
    'PROCTOR VERIFICATION: Check whether candidate was authorized to use multiple monitors during the assessment.'
}

# ==============================================================================
# 2. REMOTE ACCESS PORTS, RDP & EVENT LOGS
# ==============================================================================
Write-Host '  [2/5] Checking Remote Access Ports, RDP & Windows Event Logs...' -ForegroundColor Cyan

# Check established remote connections on ports (Inbound and Outbound)
$flaggedPorts = @(3389, 5900, 5901, 5902, 5903, 5938, 7070, 21115, 21116, 21117, 21118, 21119)
Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue |
  Where-Object { $_.LocalPort -in $flaggedPorts -or $_.RemotePort -in $flaggedPorts } | ForEach-Object {
    $isIncoming = $_.LocalPort -in $flaggedPorts
    $portNum = if ($isIncoming) { $_.LocalPort } else { $_.RemotePort }
    $pName = try { (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).Name } catch { '' }
    $desc = if ($portNum -in 5900..5903) { "VNC / Screen Sharing" } elseif ($portNum -eq 3389) { "RDP Session" } else { "Remote Desktop" }
    $dirStr = if ($isIncoming) { "Incoming $desc on Port $portNum from $($_.RemoteAddress)" } else { "Outgoing $desc to $($_.RemoteAddress):$portNum" }
    Record-Proof 'REMOTE ACCESS' ("Active Remote Connection: {0}" -f $dirStr) `
      ("Local: {0}:{1} | Remote: {2}:{3} (Process: {4}, PID: {5})" -f $_.LocalAddress, $_.LocalPort, $_.RemoteAddress, $_.RemotePort, $pName, $_.OwningProcess) `
      'PROCTOR VERIFICATION: An active remote desktop connection is established right now between this laptop and an outside machine.'
  }

# Check Windows Terminal Services / RDP Event Logs during assessment window
if ($isAdmin) {
  try {
    # Query all session lifecycle events (21=Logon, 25=Reconnect, 24=Disconnect, 23=Logoff)
    $rdpEvents = Get-WinEvent -FilterHashtable @{
      LogName   = 'Microsoft-Windows-TerminalServices-LocalSessionManager/Operational'
      StartTime = $since
      Id        = 21, 23, 24, 25
    } -ErrorAction SilentlyContinue | Sort-Object TimeCreated

    if ($rdpEvents) {
      $starts = @($rdpEvents | Where-Object { $_.Id -in 21, 25 })
      $ends   = @($rdpEvents | Where-Object { $_.Id -in 23, 24 })
      
      if ($starts.Count -gt 0) {
        $firstStart = $starts[0].TimeCreated
        $lastEnd    = if ($ends.Count -gt 0) { $ends[-1].TimeCreated } else { $null }
        $user       = try { $starts[0].Properties[0].Value } catch { 'Unknown' }
        $srcIp      = try { $starts[0].Properties[2].Value } catch { 'Unknown' }

        # Check if RDP port 3389 is currently established
        $liveRdp = Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue | Where-Object { $_.LocalPort -eq 3389 -or $_.RemotePort -eq 3389 }

        if ($liveRdp -or (-not $lastEnd) -or ($lastEnd -lt $firstStart)) {
          $timeSummary = "started at {0:yyyy-MM-dd HH:mm:ss} (ACTIVE RIGHT NOW)" -f $firstStart
          Record-Proof 'REMOTE ACCESS' ("LIVE RDP Remote Desktop Session ({0})" -f $timeSummary) `
            ("Remote User: {0} | Client IP: {1} | Session Window: {2}" -f $user, $srcIp, $timeSummary) `
            'PROCTOR VERIFICATION: A remote user is actively connected to this laptop right now via Windows Remote Desktop (RDP).'
        } else {
          $duration = $lastEnd - $firstStart
          $durStr = if ($duration.TotalSeconds -ge 0) {
            " (total duration: {0}m {1}s)" -f [int]$duration.TotalMinutes, ($duration.Seconds)
          } else { "" }
          $timeSummary = "from {0:yyyy-MM-dd HH:mm:ss} to {1:yyyy-MM-dd HH:mm:ss}{2}" -f $firstStart, $lastEnd, $durStr

          Record-Proof 'REMOTE ACCESS' ("RDP Remote Desktop Session Recorded ({0})" -f $timeSummary) `
            ("Remote User: {0} | Client IP: {1} | Session Window: {2} | Start: {3:yyyy-MM-dd HH:mm:ss} | End: {4:yyyy-MM-dd HH:mm:ss}" -f $user, $srcIp, $timeSummary, $firstStart, $lastEnd) `
            'PROCTOR VERIFICATION: A remote user connected to this laptop via Windows Remote Desktop (RDP) during the examination lookback window.'
        }
      }
    }
  } catch {}

  try {
    $rdpAuth = Get-WinEvent -FilterHashtable @{
      LogName   = 'Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational'
      StartTime = $since
      Id        = 1149
    } -ErrorAction SilentlyContinue
    foreach ($ev in $rdpAuth) {
      Record-Proof 'REMOTE ACCESS' 'Incoming RDP Connection Authenticated' `
        ("Time: {0:yyyy-MM-dd HH:mm:ss} | Remote Client IP: {1} | Account: {2}\{3}" -f $ev.TimeCreated, $ev.Properties[2].Value, $ev.Properties[1].Value, $ev.Properties[0].Value) `
        'PROCTOR VERIFICATION: Inbound RDP connection was successfully authenticated during the assessment.'
    }
  } catch {}
}

# Check AnyDesk Session Trace Logs on Windows (Actual active or recorded sessions only)
$adTracePaths = @(
  "$env:APPDATA\AnyDesk\anydesk.trace",
  "$env:ALLUSERSPROFILE\AnyDesk\ad_svc.trace",
  "$env:ALLUSERSPROFILE\AnyDesk\ad.trace"
)
foreach ($adTrace in $adTracePaths) {
  if (Test-Path $adTrace) {
    try {
      $lines = Get-Content $adTrace -ErrorAction SilentlyContinue
      $curStart = $null
      foreach ($line in $lines) {
        if ($line -match 'app\.frontend_session - Received new|app\.session - Logged in from') {
          if ($line -match '(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})') {
            $t = [DateTime]::Parse($matches[1])
            if ($t -ge $since) { $curStart = $t }
          }
        } elseif ($line -match 'app\.frontend_session - Session stopped|app\.frontend_session - The user has requested a connection quit') {
          if ($curStart -and ($line -match '(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})')) {
            $curEnd = [DateTime]::Parse($matches[1])
            $duration = $curEnd - $curStart
            $durStr = if ($duration.TotalSeconds -ge 0) { " (total duration: {0}m {1}s)" -f [int]$duration.TotalMinutes, $duration.Seconds } else { "" }
            $timeSummary = "from {0:yyyy-MM-dd HH:mm:ss} to {1:yyyy-MM-dd HH:mm:ss}{2}" -f $curStart, $curEnd, $durStr
            Record-Proof 'REMOTE ACCESS' ("Screen Shared via AnyDesk ({0})" -f $timeSummary) `
              ("Session Window: {0} | App: AnyDesk | Start: {1:yyyy-MM-dd HH:mm:ss} | End: {2:yyyy-MM-dd HH:mm:ss}" -f $timeSummary, $curStart, $curEnd) `
              'PROCTOR VERIFICATION: Candidate actively shared their screen or granted remote desktop control via AnyDesk during the assessment window.'
            $curStart = $null
          }
        }
      }
      if ($curStart) {
        $timeSummary = "started at {0:yyyy-MM-dd HH:mm:ss} (ACTIVE RIGHT NOW)" -f $curStart
        Record-Proof 'REMOTE ACCESS' ("LIVE Screen Shared via AnyDesk ({0})" -f $timeSummary) `
          ("Session Window: {0} | App: AnyDesk | Start: {1:yyyy-MM-dd HH:mm:ss} (Ongoing Session)" -f $timeSummary, $curStart) `
          'PROCTOR VERIFICATION: Candidate is actively sharing their screen via AnyDesk right now.'
      }
    } catch {}
  }
}

# ==============================================================================
# 3. LIVE ACTIVE WINDOWS OPEN RIGHT NOW (FOREGROUND ON SCREEN)
# ==============================================================================
Write-Host '  [3/5] Checking Active Windows Open on Desktop...' -ForegroundColor Cyan

$flaggedWin = @{}

Get-Process | Where-Object { $_.MainWindowTitle } | ForEach-Object {
  $name = $_.Name
  $title = $_.MainWindowTitle
  if ($title -match 'Gemini|ChatGPT|Claude|DeepSeek|Copilot|LeetCode.*Solution|HackerRank.*Solution') {
    if (-not $flaggedWin.ContainsKey($title)) {
      $flaggedWin[$title] = @{ Name = $name; Title = $title; Id = $_.Id }
    }
  }
}

foreach ($win in $flaggedWin.Values) {
  Record-Proof 'LIVE OPEN WINDOW' ("Active Window: {0}" -f $win.Title) `
    ("Application: {0} (PID: {1}) | Window Title: `"{2}`"" -f $win.Name, $win.Id, $win.Title) `
    'PROCTOR VERIFICATION: An AI assistant or solution window is visible on candidate desktop right now.'
}

# ==============================================================================
# 4. BAM EXECUTION HISTORY (PROGRAMS LAUNCHED IN TEST WINDOW)
# ==============================================================================
Write-Host '  [4/5] Checking Program Execution History (BAM Registry)...' -ForegroundColor Cyan

if ($isAdmin) {
  $bam = 'HKLM:\SYSTEM\CurrentControlSet\Services\bam\State\UserSettings'
  if (Test-Path $bam) {
    foreach ($k in (Get-ChildItem $bam -ErrorAction SilentlyContinue)) {
      foreach ($n in $k.GetValueNames()) {
        if ($n -match '^\\Device|^[A-Za-z]:\\') {
          if ($n -match 'Microsoft VS Code.*copilot-sdk|copilot-runtime|cursoruiviewservice|coreparsec|fairplayd|universalcontrol|antigravity') { continue }
          $d = $k.GetValue($n)
          if ($d -is [byte[]] -and $d.Length -ge 8) {
            $t = [DateTime]::FromFileTime([BitConverter]::ToInt64($d, 0))
            if ($t -ge $since) {
              if ($n -match $cats['AI-CHEAT']) {
                $baseApp = [IO.Path]::GetFileNameWithoutExtension($n)
                Record-Proof 'AI CHEAT TOOL' ("AI Tool Executed during Test: {0}" -f [IO.Path]::GetFileName($n)) `
                  ("Executed at: {0:yyyy-MM-dd HH:mm:ss} | Path: {1}" -f $t, $n) `
                  ("PROCTOR VERIFICATION: AI coding assistant or interview evasion tool ({0}) was executed during the examination window. Used to automatically scrape problems and generate solutions." -f $baseApp)
              }
            }
          }
        }
      }
    }
  }
}

# ==============================================================================
# 5. DEEP BROWSER HISTORY FORENSICS & EXACT AI CHAT TIMELINE
# ==============================================================================
Write-Host '  [5/5] Deep-checking Browser History & Exact AI Chat Timeline...' -ForegroundColor Cyan

$chromiumRoots = @(
  @{ N = 'Chrome';    P = "$env:LOCALAPPDATA\Google\Chrome\User Data" },
  @{ N = 'Edge';      P = "$env:LOCALAPPDATA\Microsoft\Edge\User Data" },
  @{ N = 'Brave';     P = "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data" },
  @{ N = 'Vivaldi';   P = "$env:LOCALAPPDATA\Vivaldi\User Data" },
  @{ N = 'Arc';       P = "$env:LOCALAPPDATA\Arc\User Data" },
  @{ N = 'Opera';     P = "$env:APPDATA\Opera Software\Opera Stable" },
  @{ N = 'Opera GX';  P = "$env:APPDATA\Opera Software\Opera GX Stable" },
  @{ N = 'Chromium';  P = "$env:LOCALAPPDATA\Chromium\User Data" }
)

$histFiles = foreach ($b in $chromiumRoots) {
  if (Test-Path $b.P) {
    $rootHist = Join-Path $b.P 'History'
    if (Test-Path $rootHist) {
      [pscustomobject]@{ Browser = $b.N; Profile = 'Default'; Path = $rootHist; Dir = $b.P }
    }
    Get-ChildItem $b.P -Directory -ErrorAction SilentlyContinue | ForEach-Object {
      $h = Join-Path $_.FullName 'History'
      if (Test-Path $h) {
        [pscustomobject]@{ Browser = $b.N; Profile = $_.Name; Path = $h; Dir = $_.FullName }
      }
    }
  }
}

$sqlSrc = @"
using System;
using System.Runtime.InteropServices;
using System.Collections.Generic;

public static class WSql {
  [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
  public static extern int sqlite3_open_v2([MarshalAs(UnmanagedType.LPStr)] string f, out IntPtr db, int flags, IntPtr vfs);

  [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
  public static extern int sqlite3_prepare_v2(IntPtr db, [MarshalAs(UnmanagedType.LPStr)] string sql, int n, out IntPtr st, IntPtr tail);

  [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
  public static extern int sqlite3_step(IntPtr st);

  [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
  public static extern IntPtr sqlite3_column_text(IntPtr st, int i);

  [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
  public static extern int sqlite3_column_count(IntPtr st);

  [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
  public static extern int sqlite3_finalize(IntPtr st);

  [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
  public static extern int sqlite3_close(IntPtr db);

  public static List<string> Query(string file, string sql) {
    var res = new List<string>();
    IntPtr db, st;
    if (sqlite3_open_v2(file, out db, 1, IntPtr.Zero) != 0) return null;
    if (sqlite3_prepare_v2(db, sql, -1, out st, IntPtr.Zero) != 0) { sqlite3_close(db); return null; }
    while (sqlite3_step(st) == 100) {
      int cols = sqlite3_column_count(st);
      var row = new List<string>();
      for (int i = 0; i < cols; i++) {
        IntPtr p = sqlite3_column_text(st, i);
        row.Add(p == IntPtr.Zero ? "" : Marshal.PtrToStringAnsi(p));
      }
      res.Add(string.Join("\t", row));
    }
    sqlite3_finalize(st);
    sqlite3_close(db);
    return res;
  }
}
"@

$sqlOk = $true
try { Add-Type -TypeDefinition $sqlSrc -ErrorAction Stop } catch { $sqlOk = $false }
$cutoff = [long]($since.ToUniversalTime().ToFileTimeUtc() / 10)

foreach ($h in $histFiles) {
  $tempRoot = [System.IO.Path]::GetTempPath()
  $td = Join-Path $tempRoot ("tpv_audit_{0}" -f [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $td -Force | Out-Null
  
  $tmpDb = Join-Path $td 'History'
  $tmpShort = Join-Path $td 'Shortcuts'
  
  # Safe non-locking file copy of local browser history for read-only audit
  if (-not (Safe-CopyFile $h.Path $tmpDb)) {
    Remove-Item $td -Recurse -Force -ErrorAction SilentlyContinue
    continue
  }
  
  $shortSrc = Join-Path $h.Dir 'Shortcuts'
  if (Test-Path $shortSrc) { Safe-CopyFile $shortSrc $tmpShort | Out-Null }

  # Detect Account associated with this profile from clean Preferences JSON
  $profAccount = "Unknown"
  $prefFile = Join-Path $h.Dir 'Preferences'
  if (Test-Path $prefFile) {
    try {
      $prefTxt = [IO.File]::ReadAllText($prefFile)
      $emMatch = [regex]::Match($prefTxt, '"email"\s*:\s*"([^"]+@[^"]+\.[^"]+)"')
      if ($emMatch.Success) { $profAccount = $emMatch.Groups[1].Value }
    } catch {}
  }

  $rows = $null
  
  if ($sqlOk) {
    # 1. Query active visits in History database
    $q = "SELECT datetime(v.visit_time/1000000 - 11644473600, 'unixepoch', 'localtime'), coalesce(v.visit_duration/1000000, 0), u.url, replace(replace(coalesce(u.title, ''), char(10), ' '), char(13), ' '), cast(v.visit_time/1000000-11644473600 as integer), coalesce(v.originator_cache_guid, '') FROM visits v JOIN urls u ON u.id = v.url WHERE v.visit_time > $cutoff ORDER BY v.visit_time ASC"
    try { $rows = [WSql]::Query($tmpDb, $q) } catch {}

    # 2. Check for Deleted URLs in Shortcuts Cache (Omnibox Autocomplete)
    if (Test-Path $tmpShort) {
      $sRows = [WSql]::Query($tmpShort, "SELECT replace(replace(text, char(10), ' '), char(13), ' '), replace(replace(url, char(10), ' '), char(13), ' '), datetime(last_access_time/1000000-11644473600, 'unixepoch', 'localtime'), cast(last_access_time/1000000-11644473600 as integer) FROM omni_box_shortcuts WHERE last_access_time > $cutoff;")
      if ($sRows) {
        $delShortcuts = @{}
        foreach ($sr in $sRows) {
          $sp = $sr -split "`t"
          if ($sp.Length -ge 4) {
            $sUrl = $sp[1]
            $sTime = $sp[2]
            $sEpoch = [int64]$sp[3]
            if ($sEpoch -gt 0) {
              try { $sTime = [DateTimeOffset]::FromUnixTimeSeconds($sEpoch).ToLocalTime().ToString('yyyy-MM-dd HH:mm:ss') } catch {}
            }
            if ($sUrl -match $domains -and -not (Is-GarbageUrl $sUrl)) {
              $toolName = Tool-Of $sUrl
              $inActRow = [WSql]::Query($tmpDb, "SELECT count(*) FROM visits v JOIN urls u ON u.id = v.url WHERE u.url = '$sUrl' AND v.visit_time > $cutoff;")
              $inActCount = if ($inActRow -and $inActRow.Count -gt 0) { [int]$inActRow[0] } else { 0 }
              if ($inActCount -eq 0) {
                if (-not $delShortcuts.ContainsKey($toolName)) { $delShortcuts[$toolName] = New-Object System.Collections.Generic.List[string] }
                $delShortcuts[$toolName].Add($sUrl)
                
                $script:historyTimeline.Add([pscustomobject]@{
                  Time     = $sTime
                  Browser  = $h.Browser
                  Profile  = $h.Profile
                  Account  = $profAccount
                  Tool     = $toolName
                  Device   = "Local Laptop"
                  Duration = 0
                  Url      = $sUrl
                  Title    = "[DELETED HISTORY] $toolName"
                })
              }
            }
          }
        }
        foreach ($tn in $delShortcuts.Keys) {
          $uList = ($delShortcuts[$tn] | Select-Object -First 3) -join ' | '
          Record-Proof 'TAMPERING / DELETION' ("Deleted {0} History Recovered in {1} (Account: {2})" -f $tn, $h.Browser, $profAccount) `
            ("Candidate visited {0} ({1} URLs recovered from Omnibox shortcut cache: {2})." -f $tn, $delShortcuts[$tn].Count, $uList) `
            'PROCTOR VERIFICATION: Candidate opened this AI tool during the exam and then deleted browsing history to hide it. The URLs were forensically recovered from the browser shortcut cache.'
        }
      }
    }
  }
  
  Remove-Item $td -Recurse -Force -ErrorAction SilentlyContinue
  
  if ($null -eq $rows) { continue }
  
  foreach ($r in $rows) {
    $parts = $r -split "`t"
    if ($parts.Length -lt 3) { continue }
    $dur = [int]0
    [int]::TryParse($parts[1], [ref]$dur) | Out-Null
    $url = $parts[2]
    $title = if ($parts.Length -gt 3) { $parts[3] } else { '' }
    
    $vtime = $parts[0]
    $epochSec = [int64]0
    if ($parts.Length -gt 4) { [int64]::TryParse($parts[4], [ref]$epochSec) | Out-Null }
    if ($epochSec -gt 0) {
      try {
        $vtime = [DateTimeOffset]::FromUnixTimeSeconds($epochSec).ToLocalTime().ToString('yyyy-MM-dd HH:mm:ss')
      } catch {}
    }
    
    $oguid = if ($parts.Length -gt 5) { $parts[5] } else { '' }
    $dev = if ($oguid) { "Mobile Phone / Synced Device (ID: $oguid)" } else { "Local Laptop" }
    
    # Drop OAuth, login, and Google Account plumbing URLs
    if (Is-GarbageUrl $url) { continue }
    
    $isMatch = $false
    if ($url -match $domains) {
      $isMatch = $true
    } elseif ($url -match 'google\.com/search|bing\.com/search' -and "$url $title" -match $searchCheat) {
      $isMatch = $true
    }
    
    if ($isMatch) {
      $tool = Get-FriendlyTool $url
      $script:historyTimeline.Add([pscustomobject]@{
        Time     = $vtime
        Browser  = $h.Browser
        Profile  = $h.Profile
        Account  = $profAccount
        Tool     = $tool
        Device   = $dev
        Duration = $dur
        Url      = $url
        Title    = $title
      })
    }
  }
}

# Aggregate Browser History into High-Confidence Proof Dossier
if ($script:historyTimeline.Count -gt 0) {
  $grouped = $script:historyTimeline | Group-Object { "$($_.Tool) in $($_.Browser) (Account: $($_.Account), $($_.Device))" }
  foreach ($g in $grouped) {
    $firstHit = $g.Group | Sort-Object Time | Select-Object -First 1
    $lastHit  = $g.Group | Sort-Object Time | Select-Object -Last 1
    $totalDur = ($g.Group | Measure-Object -Property Duration -Sum).Sum
    $dMin = [int]($totalDur / 60); $dSec = $totalDur % 60
    
    $span = if ($firstHit.Time -eq $lastHit.Time) { "at $($firstHit.Time)" } else { "from $($firstHit.Time) to $($lastHit.Time)" }
    $durStr = if ($totalDur -gt 0) { "active: ${dMin}m ${dSec}s" } else { "dwell: 0s / glance" }
    
    Record-Proof 'AI CHAT / BROWSER HISTORY' `
      ("{0} was opened {1} ({2} visits, {3})" -f $g.Name, $span, $g.Count, $durStr) `
      ("History database record confirmed during OA window.") `
      'PROCTOR VERIFICATION: Candidate opened and engaged with this AI/solver tool during the assessment.'
  }
}

# ==============================================================================
# AUDIT VERDICT & EVIDENCE DOSSIER (WITH 5-SECOND INVIGILATOR CHECKLIST)
# ==============================================================================
Write-Host ''
Write-Host ('=' * 72)
if ($script:proofList.Count -gt 0) {
  Write-Host "  PROCTOR VERDICT: [!] CHEATING / EVASION DETECTED ($($script:proofList.Count) violation items)" -ForegroundColor Red
  Write-Host "  Candidate Computer: $env:COMPUTERNAME   |   User: $env:USERNAME"
  Write-Host "  Audit Lookback: Last $Hours hour(s)   |   Verified: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
  Write-Host ''
  Write-Host '  INVIGILATOR 5-SECOND CHECKLIST:' -ForegroundColor White

  $hasMirror  = $script:proofList | Where-Object { $_.Category -match 'SCREEN MIRRORING|HARDWARE CAPTURE|MULTI-DISPLAY' }
  $hasRemote  = $script:proofList | Where-Object { $_.Category -eq 'REMOTE ACCESS' }
  $hasLiveWin = $script:proofList | Where-Object { $_.Category -eq 'LIVE OPEN WINDOW' }
  $hasAiApp   = $script:proofList | Where-Object { $_.Category -eq 'AI CHEAT TOOL' }
  $hasHist    = $script:proofList | Where-Object { $_.Category -eq 'AI CHAT / BROWSER HISTORY' }
  $hasDel     = $script:proofList | Where-Object { $_.Category -eq 'TAMPERING / DELETION' }

  if ($hasMirror -or ($script:proofList | Where-Object { $_.Title -match 'Screen Sharing|VNC' })) {
    Write-Host '    [!] Screen Mirroring / Remote Sharing : DETECTED (Screen Sharing/VNC)' -ForegroundColor Red
  } else {
    Write-Host '    [✓] Screen Mirroring / Display Cloning : Clean' -ForegroundColor Green
  }

  if ($hasRemote) {
    $rdTools = @()
    if ($script:proofList | Where-Object { $_.Evidence -match 'AnyDesk' -or $_.Title -match 'AnyDesk' }) { $rdTools += 'AnyDesk' }
    if ($script:proofList | Where-Object { $_.Evidence -match 'TeamViewer' -or $_.Title -match 'TeamViewer' }) { $rdTools += 'TeamViewer' }
    if ($script:proofList | Where-Object { $_.Evidence -match 'RustDesk' -or $_.Title -match 'RustDesk' }) { $rdTools += 'RustDesk' }
    if ($script:proofList | Where-Object { $_.Evidence -match 'VNC' -or $_.Title -match 'VNC|Screen Sharing' }) { $rdTools += 'VNC' }
    if ($script:proofList | Where-Object { $_.Evidence -match 'RDP' -or $_.Title -match 'RDP' }) { $rdTools += 'RDP' }
    if ($rdTools.Count -eq 0) { $rdTools += 'Active Remote Tool' }
    $toolStr = ($rdTools | Select-Object -Unique) -join '/'
    Write-Host ("    [!] Remote Screen Share / Control Session : DETECTED ({0})" -f $toolStr) -ForegroundColor Red
  } else {
    Write-Host '    [✓] Remote Screen Share / Control Session : Clean' -ForegroundColor Green
  }

  if ($hasLiveWin) {
    $winTitles = ($hasLiveWin | ForEach-Object { $_.Title }) -join ', '
    Write-Host ("    [!] Live AI Tabs / Windows Open        : DETECTED ({0})" -f $winTitles) -ForegroundColor Red
  } else {
    Write-Host '    [✓] Live AI Tabs / Windows Open        : Clean' -ForegroundColor Green
  }

  if ($hasHist) {
    Write-Host '    [!] AI Website / Solver Visited        : DETECTED' -ForegroundColor Red
  } else {
    Write-Host '    [✓] AI Website / Solver Visited        : Clean' -ForegroundColor Green
  }

  if ($hasDel) {
    Write-Host '    [!] Browser History Wiped / Tampered   : DETECTED (Recovered from shortcut cache)' -ForegroundColor Red
  } else {
    Write-Host '    [✓] Browser History Wiped / Tampered   : Clean' -ForegroundColor Green
  }
  Write-Host ('=' * 72)
  
  $idx = 1
  foreach ($p in $script:proofList) {
    Write-Host ''
    Write-Host ("  [PROOF #{0}] {1}: {2}" -f $idx, $p.Category, $p.Title) -ForegroundColor Red
    Write-Host ("    Evidence: {0}" -f $p.Evidence) -ForegroundColor Cyan
    Write-Host ("    Proctor Meaning: {0}" -f $p.Meaning) -ForegroundColor Yellow
    $idx++
  }
} else {
  Write-Host '  PROCTOR VERDICT: [✓] CLEAN - NO CHEATING DETECTED' -ForegroundColor Green
  Write-Host "  Candidate Computer: $env:COMPUTERNAME   |   User: $env:USERNAME"
  Write-Host "  Audit Lookback: Last $Hours hour(s)   |   Verified: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
  Write-Host ''
  Write-Host '  INVIGILATOR 5-SECOND CHECKLIST:' -ForegroundColor White
  Write-Host '    [✓] Screen Mirroring / Display Cloning : Clean' -ForegroundColor Green
  Write-Host '    [✓] Remote Screen Share / Control Session : Clean' -ForegroundColor Green
  Write-Host '    [✓] Live AI Tabs / Windows Open        : Clean' -ForegroundColor Green
  Write-Host '    [✓] AI Website / Solver Visited        : Clean' -ForegroundColor Green
  Write-Host '    [✓] Browser History Wiped / Tampered   : Clean' -ForegroundColor Green
  Write-Host ('=' * 72)
}

# ==============================================================================
# CONSOLIDATED AI ACTIVITY WINDOWS (Merged Session Timeline)
# ==============================================================================
if ($script:historyTimeline.Count -gt 0) {
  Write-Host ''
  Write-Host ('=' * 72)
  Write-Host '  CONSOLIDATED AI & CHEATING TIMELINE (MERGED WINDOWS)' -ForegroundColor Cyan
  Write-Host ('=' * 72)
  
  $sessions = New-Object System.Collections.Generic.List[object]
  $sorted = $script:historyTimeline | Sort-Object Time
  $currentSession = $null
  
  foreach ($hit in $sorted) {
    $t = (Get-Date)
    [DateTime]::TryParse($hit.Time, [ref]$t) | Out-Null
    $dev = if ($hit.Device) { $hit.Device } else { 'Local Laptop' }
    $acc = if ($hit.Account) { $hit.Account } else { 'Primary Account' }
    $key = "$($hit.Tool)|$($hit.Browser)|$($hit.Profile)|$dev|$acc"
    
    if ($null -eq $currentSession -or $currentSession.Key -ne $key -or ($t - $currentSession.LastTime).TotalMinutes -gt 5) {
      if ($null -ne $currentSession) {
        $sessions.Add($currentSession)
      }
      $currentSession = [pscustomobject]@{
        Key        = $key
        Tool       = $hit.Tool
        Browser    = $hit.Browser
        Profile    = $hit.Profile
        Account    = $acc
        Device     = $dev
        StartTime  = $hit.Time
        EndTime    = $hit.Time
        LastTime   = $t
        TotalDur   = [int]$hit.Duration
        Count      = 1
        UniqueUrls = @{ $hit.Url = $hit.Title }
      }
    } else {
      $currentSession.EndTime = $hit.Time
      $currentSession.LastTime = $t
      $currentSession.TotalDur += [int]$hit.Duration
      $currentSession.Count++
      $currentSession.UniqueUrls[$hit.Url] = $hit.Title
    }
  }
  if ($null -ne $currentSession) {
    $sessions.Add($currentSession)
  }
  
  $sIdx = 1
  foreach ($s in $sessions) {
    $span = if ($s.StartTime -eq $s.EndTime) { "at $($s.StartTime)" } else { "from $($s.StartTime) to $($s.EndTime)" }
    $dm = [int]($s.TotalDur / 60); $ds = $s.TotalDur % 60
    Write-Host ''
    Write-Host ("  [WINDOW #{0}] {1} was opened in {2} (Profile: {3})" -f $sIdx, $s.Tool, $s.Browser, $s.Profile) -ForegroundColor Red
    Write-Host ("    * Account Used  : {0}" -f $s.Account) -ForegroundColor Yellow
    Write-Host ("    * Device Origin : {0}" -f $s.Device) -ForegroundColor Cyan
    Write-Host ("    * Time Window   : {0}" -f $span) -ForegroundColor DarkGray
    Write-Host ("    * Interactions  : {0} visits (total recorded active dwell time: {1}m {2}s)" -f $s.Count, $dm, $ds) -ForegroundColor DarkGray
    Write-Host  "    * Specific Chat / Problem URLs Accessed:" -ForegroundColor DarkGray
    foreach ($u in $s.UniqueUrls.Keys) {
      $tit = $s.UniqueUrls[$u]
      if ($tit) { $tit = " - `"$tit`"" }
      Write-Host ("        - {0}{1}" -f $u, $tit) -ForegroundColor Yellow
    }
    $sIdx++
  }
}

Write-Host ''
Write-Host ('=' * 72)
Write-Host '  AUDIT COMPLETE: All evidence presented is verified against local system records.'
Write-Host ('=' * 72)
Write-Host ''
