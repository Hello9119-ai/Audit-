@echo off
setlocal
cd /d "%~dp0"
echo ========================================================================
echo   Compiling Standalone Native Windows Audit.exe
echo ========================================================================
set "CSC=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe"

if exist "%CSC%" (
    "%CSC%" /target:exe /out:Audit.exe /optimize+ /platform:anycpu Audit.cs
    if %errorlevel% equ 0 (
        echo [OK] Audit.exe compiled successfully!
        echo You can now double-click Audit.exe on any Windows laptop.
    ) else (
        echo [!] Using PowerShell compiler fallback...
        powershell -NoProfile -Command "Add-Type -TypeDefinition (Get-Content Audit.cs -Raw) -OutputAssembly 'Audit.exe' -OutputType ConsoleApplication"
    )
) else (
    echo Using PowerShell compiler fallback...
    powershell -NoProfile -Command "Add-Type -TypeDefinition (Get-Content Audit.cs -Raw) -OutputAssembly 'Audit.exe' -OutputType ConsoleApplication"
)
echo.
pause
