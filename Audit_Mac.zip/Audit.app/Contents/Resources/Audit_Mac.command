#!/bin/bash
# ==============================================================================
# TPV Post-Assessment High-Confidence Forensic Audit (macOS)
# Focused STRICTLY on hard proof:
#   1. AI Question Solving & Chat (Gemini, ChatGPT, Claude, DeepSeek, etc.)
#   2. Active Screen Mirroring (Hardware clone, AirPlay receiver, Sidecar)
#   3. Remote Control & Screen Sharing (VNC, AnyDesk, TeamViewer, RustDesk)
#
# Consolidates repetitive URL visits into clear, distinct session windows.
# Ignores: VPNs, inactive background apps, leftover folders, and OS system noise.
# Run: bash Audit_Mac.command [hours]
# ==============================================================================

# Handle audit lookback window (Default: 2 hours, or prompts if interactive)
if [ -n "$1" ]; then
  HOURS="$1"
elif [ -t 0 ] || [ -c /dev/tty ]; then
  printf "\033[1;36mEnter audit lookback window in hours [Press Enter for default: 2]: \033[0m"
  if read -r user_input </dev/tty 2>/dev/null; then
    if [ -n "$user_input" ] && [ "$user_input" -eq "$user_input" ] 2>/dev/null && [ "$user_input" -gt 0 ]; then
      HOURS="$user_input"
    else
      HOURS=2
    fi
  else
    HOURS=2
  fi
else
  HOURS=2
fi

SECS=$((HOURS * 3600))
DIR="$(cd "$(dirname "$0")" && pwd)"
PROOF_F=$(mktemp)
TIMELINE_F=$(mktemp)
APPSF=$(mktemp)

# fd 3 = terminal view for proctor; standard stdout/stderr discarded
exec 3>&1
exec >/dev/null 2>&1

CLR_R=$'\033[31m'; CLR_G=$'\033[32m'; CLR_Y=$'\033[33m'; CLR_C=$'\033[36m'; CLR_B=$'\033[1m'; CLR_N=$'\033[0m'
say() { printf '%s\n' "$*" >&3; }

# Targeted High-Severity Signatures ONLY (Strictly AI, Remote, and Screen Mirroring)
REMOTE='anydesk|teamviewer|rustdesk|ultraviewer|splashtop|parsec|logmein|vnc|radmin|screenconnect|connectwise|nomachine|remotepc|chrome ?remote|remoting_host|todesk|sunlogin|getscreen|meshagent|zoho ?assist|airdroid|scrcpy|vysor|jump ?desktop|moonlight|sunshine|letsview|apowermirror|screen ?sharing|screensharing|screensharingd|ardagent'
MIRROR='screen ?sharing|screensharing|screensharingd|airplayscreenservice|sidecardisplayagent|betterdisplay|dummydisplay|deskreen|spacedesk|luna ?display|displaylink|airserver|reflector'
AI='cluely|interview ?coder|final ?round|lockedin|parakeet|leetcode ?wizard|chatgpt|openai|deepseek|perplexity|ollama|lm ?studio|gpt4all|claude|gemini|copilot|grok|blackbox|cursor|phind|poe|cody|tabnine|superwhisper|macwhisper|wispr|plaud|whisper|mistral|v0\.dev|bolt\.new|lovable'
CHEATING_APPS="$REMOTE|$MIRROR|$AI"

# Browser Cheating & Clean AI Domains (Excludes login / oauth garbage)
DOMAINS='^https?://(gemini\.google\.com/app|share\.gemini\.google|chatgpt\.com|chat\.openai\.com|claude\.ai|deepseek\.com|chat\.deepseek\.com|perplexity\.ai|copilot\.microsoft\.com|grok\.com|blackbox\.ai|phind\.com|poe\.com|chegg\.com|coursehero\.com|brainly\.com|quizlet\.com|symbolab\.com|wolframalpha\.com|mathway\.com|cluely\.com|interviewcoder\.co|finalroundai\.com|lockedinai\.com|remotedesktop\.google\.com)'
SEARCH_CHEAT='(leetcode|hackerrank|interview.*coder|cheat|answer|solution|oa.*test|proctor|bypass)'

is_garbage_url() {
  case "$1" in
    *accounts.google.com*|*gds.google.com*|*myaccount.google.com*|*policies.google.com*|*support.google.com*|*appleid.apple.com*|*login.live.com*|*login.microsoftonline.com*|*auth0.openai.com*|*/signin*|*/login*|*CheckCookie*|*SetSID*|*SetOSID*|*oauth*|*/auth?*|*/auth/*|*challenge/pk*|*accountchooser*|*continue=*|*ServiceLogin*|*InteractiveLogin*)
      return 0 ;;
    *)
      return 1 ;;
  esac
}

tool_of() {
  case "$1" in
    *gemini.google.com*) echo "Google Gemini" ;;
    *chatgpt.com*|*chat.openai.com*) echo "ChatGPT (OpenAI)" ;;
    *claude.ai*) echo "Claude (Anthropic)" ;;
    *deepseek.com*) echo "DeepSeek AI" ;;
    *perplexity.ai*) echo "Perplexity AI" ;;
    *copilot.microsoft.com*) echo "Microsoft Copilot" ;;
    *grok.com*) echo "Grok AI" ;;
    *blackbox.ai*) echo "Blackbox AI" ;;
    *poe.com*|*phind.com*) echo "AI Search/Solver" ;;
    *cluely.com*|*interviewcoder*|*finalroundai*|*lockedinai*) echo "Interview Cheating Overlay" ;;
    *chegg.com*|*coursehero.com*|*brainly.com*) echo "Academic Answer Site" ;;
    *remotedesktop.google.com*|*anydesk.com*|*teamviewer.com*|*rustdesk.com*|*parsec.app*) echo "Remote Desktop Web" ;;
    *web.telegram.org*|*discord.com*|*web.whatsapp.com*) echo "Messaging During Exam" ;;
    *) echo "Flagged Web Domain" ;;
  esac
}

hdr() {
  echo; echo "========================================================================"; echo "$1"; echo "========================================================================"
  case "${1%%.*}" in
    1) n="Checking Screen Mirroring, AirPlay & Connected Displays";;
    2) n="Checking Remote Access Ports & Network Sockets";;
    3) n="Checking Live Open Browser Tabs (Brave, Chrome, Safari, Edge)";;
    4) n="Checking AI & Remote Applications Launched During Test Window";;
    5) n="Deep-checking Browser History & Exact AI Chat Timeline";;
    *) return;;
  esac
  say "  ${CLR_C}[${1%%.*}/5] $n...${CLR_N}"
}

record_proof() {
  # $1=Category, $2=Proof Title, $3=Details, $4=Proctor Meaning
  {
    echo "CATEGORY|$1"
    echo "TITLE|$2"
    echo "DETAILS|$3"
    echo "MEANING|$4"
    echo "---"
  } >> "$PROOF_F"
}

printf '\033c' >&3
say ""
say "  ${CLR_B}${CLR_C}TPV POST-ASSESSMENT FORENSIC LAPTOP AUDIT${CLR_N}"
say "  Computer: $(scutil --get ComputerName 2>/dev/null || hostname)   |   User: $(whoami)"
say "  Audit Look-back Window: Last $HOURS hour(s)   |   Time: $(date '+%Y-%m-%d %H:%M:%S')"
say "  Filtering noise: VPNs, inactive apps, and system daemons are suppressed."
say ""

# ==============================================================================
# 1. SCREEN MIRRORING, AIRPLAY & CONNECTED DISPLAYS
# ==============================================================================
hdr "1. SCREEN MIRRORING, AIRPLAY & CONNECTED DISPLAYS"

disp_out=$(system_profiler SPDisplaysDataType 2>/dev/null)
disp_count=$(echo "$disp_out" | grep -c "Resolution:")

# Check for Hardware or Software Mirroring
if echo "$disp_out" | grep -iE 'Mirror: (On|Hardware Mirror|Software Mirror|Mirror of)'; then
  mirror_detail=$(echo "$disp_out" | grep -iE 'Mirror: (On|Hardware Mirror|Software Mirror|Mirror of)' | tr -d ' ' | paste -sd, -)
  record_proof "SCREEN MIRRORING" \
    "Active Screen Mirroring / Display Cloning Detected" \
    "Display Status: $mirror_detail across $disp_count connected display(s)." \
    "PROCTOR VERIFICATION: Candidate screen is duplicated/cloned to another monitor or external display feed right now."
fi

# Check for Virtual / AirPlay / Sidecar / DisplayLink displays
if echo "$disp_out" | grep -iE 'Display Type: (AirPlay|Sidecar|Virtual|DisplayLink|Dummy)' || echo "$disp_out" | grep -iE '(AirPlay: Yes|Connection Type: (Wireless|AirPlay))'; then
  vdisp=$(echo "$disp_out" | grep -iE '(Display Type|Connection Type):' | grep -iE 'AirPlay|Sidecar|Virtual|DisplayLink|Wireless' | tr -d ' ' | paste -sd, -)
  record_proof "SCREEN MIRRORING" \
    "Virtual / Wireless / AirPlay Display Connected" \
    "Device Info: $vdisp" \
    "PROCTOR VERIFICATION: Candidate has a virtual display driver or wireless AirPlay receiver mirroring the assessment."
fi

# Active AirPlay Mirroring Receiver Process
if pgrep -lf AirPlayScreenService >/dev/null 2>&1; then
  record_proof "SCREEN MIRRORING" \
    "AirPlayScreenService Active Video Stream" \
    "Process: AirPlayScreenService is currently running." \
    "PROCTOR VERIFICATION: Candidate Mac is actively receiving or transmitting screen mirroring from/to another Mac or iPad."
fi

# Multi-monitor without mirror (potential 2nd screen cheat)
if [ "$disp_count" -gt 1 ] && ! echo "$disp_out" | grep -iE 'Mirror: (On|Hardware Mirror|Software Mirror|Mirror of)' >/dev/null; then
  record_proof "MULTI-DISPLAY" \
    "Multiple Displays Connected ($disp_count screens)" \
    "Display Resolutions: $(echo "$disp_out" | grep "Resolution:" | tr -d ' ' | paste -sd, -)" \
    "PROCTOR VERIFICATION: Verify whether candidate was authorized to use an external secondary monitor during the exam."
fi

# Hardware HDMI Capture Card / USB Video Cloner
cam_out=$(system_profiler SPCameraDataType 2>/dev/null)
if echo "$cam_out" | grep -iE 'Cam Link|HDMI|Capture|OBS Virtual|Elgato|AverMedia'; then
  cam_hit=$(echo "$cam_out" | grep -iE 'Cam Link|HDMI|Capture|OBS Virtual|Elgato|AverMedia' | head -1 | sed 's/^[ \t]*//')
  record_proof "HARDWARE CAPTURE" \
    "Hardware HDMI Screen Capture Dongle Connected" \
    "Device: $cam_hit" \
    "PROCTOR VERIFICATION: An HDMI capture card or virtual camera dongle is connected, cloning candidate screen to another PC."
fi

# ==============================================================================
# 2. REMOTE ACCESS PORTS & NETWORK SOCKETS
# ==============================================================================
hdr "2. REMOTE ACCESS PORTS & NETWORK SOCKETS"

# 1. Screen Sharing / VNC LIVE established connection right now
vnc_est=$(netstat -an 2>/dev/null | grep -E '\.(5900|590[1-9]|3283) +.*ESTABLISHED')
if [ -n "$vnc_est" ]; then
  remote_conn=$(echo "$vnc_est" | awk '{print $5}' | head -1)
  vnc_start=$(/usr/bin/log show --last "${HOURS}h" --debug --info --predicate 'process == "screensharingd" AND composedMessage CONTAINS "accept new screen sharing connection"' --style compact 2>/dev/null | grep 'accept new screen sharing connection' | awk '{print $1, substr($2,1,8)}' | tail -1)
  time_info="from ${vnc_start:-active} to PRESENT (ACTIVE RIGHT NOW)"
  record_proof "REMOTE ACCESS" \
    "LIVE Screen Sharing Connection Active Right Now ($time_info)" \
    "Remote Client: $remote_conn | Session Window: $time_info" \
    "PROCTOR VERIFICATION: An external third-party device is actively connected to this Mac right now via Screen Sharing, viewing the screen or controlling input."
fi

# 2. Check for Screen Sharing / VNC connections accepted during the exam lookback window
if [ -z "$vnc_est" ]; then
  vnc_logs=$(/usr/bin/log show --last "${HOURS}h" --debug --info --predicate 'process == "screensharingd" AND (composedMessage CONTAINS "accept new screen sharing connection" OR composedMessage CONTAINS "No viewers so time to exit")' --style compact 2>/dev/null)
  vnc_starts=$(echo "$vnc_logs" | grep 'accept new screen sharing connection' | awk '{print $1, substr($2,1,8)}')
  vnc_ends=$(echo "$vnc_logs" | grep 'No viewers so time to exit' | awk '{print $1, substr($2,1,8)}')
  first_start=$(echo "$vnc_starts" | head -1)
  last_end=$(echo "$vnc_ends" | tail -1)

  if [ -n "$first_start" ]; then
    dur_str=""
    if [ -n "$last_end" ]; then
      s_ep=$(date -j -f "%Y-%m-%d %H:%M:%S" "$first_start" "+%s" 2>/dev/null || echo 0)
      e_ep=$(date -j -f "%Y-%m-%d %H:%M:%S" "$last_end" "+%s" 2>/dev/null || echo 0)
      if [ "$e_ep" -ge "$s_ep" ] && [ "$s_ep" -gt 0 ]; then
        diff_s=$((e_ep - s_ep))
        dur_str=" (total duration: $((diff_s / 60))m $((diff_s % 60))s)"
      fi
      time_summary="from $first_start to $last_end$dur_str"
    else
      time_summary="started at $first_start"
    fi
    record_proof "REMOTE ACCESS" \
      "Screen Sharing Connection Recorded in Test Window ($time_summary)" \
      "Remote Session Window: $time_summary | Start: $first_start | End: ${last_end:-Unknown}" \
      "PROCTOR VERIFICATION: A remote third party connected to this Mac via Screen Sharing during the examination lookback window."
  fi
fi

# 3. Check for active established remote desktop connections right now
other_est=$(netstat -an 2>/dev/null | grep -E '\.(7070|5938|2111[5-9]) +.*ESTABLISHED')
if [ -n "$other_est" ]; then
  other_rip=$(echo "$other_est" | awk '{print $5}' | head -1)
  record_proof "REMOTE ACCESS" \
    "LIVE Third-Party Remote Desktop Connection Active Right Now" \
    "Connection: Established remote session with $other_rip" \
    "PROCTOR VERIFICATION: An active remote desktop connection is open right now."
fi

# 4. Check AnyDesk actual screen share sessions in lookback window (from trace logs)
cutoff_epoch=$(date -v"-${HOURS}H" +%s 2>/dev/null || date -d "-${HOURS} hours" +%s 2>/dev/null)
anydesk_trace="$HOME/.anydesk/anydesk.trace"
if [ ! -f "$anydesk_trace" ] && [ -f "/Library/Logs/AnyDesk/anydesk.trace" ]; then
  anydesk_trace="/Library/Logs/AnyDesk/anydesk.trace"
fi

if [ -f "$anydesk_trace" ]; then
  awk -v cutoff="$cutoff_epoch" '
  /app\.frontend_session - Received new|app\.session - Logged in from/ {
    match($0, /[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}/)
    if (RSTART > 0) {
      dt = substr($0, RSTART, RLENGTH)
      cmd = "date -j -f \"%Y-%m-%d %H:%M:%S\" \"" dt "\" +%s 2>/dev/null"
      cmd | getline ep
      close(cmd)
      if (ep >= cutoff) {
        start_dt = dt
        start_ep = ep
      }
    }
  }
  /app\.frontend_session - Session stopped|app\.frontend_session - The user has requested a connection quit/ {
    if (start_dt != "") {
      match($0, /[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}/)
      if (RSTART > 0) {
        end_dt = substr($0, RSTART, RLENGTH)
        cmd = "date -j -f \"%Y-%m-%d %H:%M:%S\" \"" end_dt "\" +%s 2>/dev/null"
        cmd | getline end_ep
        close(cmd)
        diff_s = end_ep - start_ep
        printf "%s\t%s\t%d\n", start_dt, end_dt, diff_s
        start_dt = ""
      }
    }
  }
  END {
    if (start_dt != "") {
      printf "%s\tACTIVE RIGHT NOW\t0\n", start_dt
    }
  }
  ' "$anydesk_trace" | while IFS=$'\t' read -r ad_start ad_end ad_diff; do
    [ -n "$ad_start" ] || continue
    if [ "$ad_end" = "ACTIVE RIGHT NOW" ]; then
      ad_summary="started at $ad_start (ACTIVE RIGHT NOW)"
    else
      ad_dm=$((ad_diff / 60))
      ad_ds=$((ad_diff % 60))
      ad_summary="from $ad_start to $ad_end (total duration: ${ad_dm}m ${ad_ds}s)"
    fi
    record_proof "REMOTE ACCESS" \
      "Screen Shared via AnyDesk ($ad_summary)" \
      "Session Window: $ad_summary | App: AnyDesk | Start: $ad_start | End: $ad_end" \
      "PROCTOR VERIFICATION: Candidate actively shared their screen or granted remote desktop control via AnyDesk during the assessment window."
  done
fi

# ==============================================================================
# 3. LIVE OPEN BROWSER TABS (CURRENT MOMENT)
# ==============================================================================
hdr "3. LIVE ACTIVE BROWSER TABS (CURRENT MOMENT)"

for app_name in "Brave Browser" "Google Chrome" "Microsoft Edge" "Arc"; do
  if pgrep -x "$app_name" >/dev/null 2>&1 || pgrep -f "$app_name.app/Contents/MacOS" >/dev/null 2>&1; then
    tabs=$(osascript -e "
      tell application \"$app_name\"
        set out to {}
        repeat with w in windows
          repeat with t in tabs of w
            set end of out to (URL of t & \"	\" & title of t)
          end repeat
        end repeat
        set AppleScript's text item delimiters to linefeed
        return out as text
      end tell" 2>/dev/null)
    
    if [ -n "$tabs" ]; then
      echo "$tabs" | sort | uniq -c | while read -r cnt u tit; do
        [ -n "$u" ] || continue
        is_garbage_url "$u" && continue
        tab_label="1 active tab"
        [ "$cnt" -gt 1 ] && tab_label="$cnt active tabs open"
        
        if echo "$u" | grep -iEq "$DOMAINS"; then
          tool=$(tool_of "$u")
          record_proof "LIVE OPEN TAB" \
            "$tool is OPEN RIGHT NOW in $app_name ($tab_label)" \
            "URL: $u | Page Title: \"$tit\"" \
            "PROCTOR VERIFICATION: Candidate currently has $tab_label of $tool open in $app_name during the examination."
        elif echo "$u" | grep -iEq 'google\.com/search|bing\.com/search' && echo "$u $tit" | grep -iEq "$SEARCH_CHEAT"; then
          record_proof "LIVE SEARCH" \
            "Search for Exam Answers / Solutions in $app_name ($tab_label)" \
            "URL: $u | Title: \"$tit\"" \
            "PROCTOR VERIFICATION: Candidate has an active search open looking for test questions or coding solutions."
        fi
      done
    fi
  fi
done

if pgrep -x "Safari" >/dev/null 2>&1; then
  stabs=$(osascript -e '
    tell application "Safari"
      set out to {}
      repeat with w in windows
        repeat with t in tabs of w
          set end of out to (URL of t & "	" & name of t)
        end repeat
      end repeat
      set AppleScript'\''s text item delimiters to linefeed
      return out as text
    end tell' 2>/dev/null)
  if [ -n "$stabs" ]; then
    echo "$stabs" | sort | uniq -c | while read -r cnt u tit; do
      [ -n "$u" ] || continue
      is_garbage_url "$u" && continue
      tab_label="1 active tab"
      [ "$cnt" -gt 1 ] && tab_label="$cnt active tabs open"
      
      if echo "$u" | grep -iEq "$DOMAINS"; then
        tool=$(tool_of "$u")
        record_proof "LIVE OPEN TAB" \
          "$tool is OPEN RIGHT NOW in Safari ($tab_label)" \
          "URL: $u | Title: \"$tit\"" \
          "PROCTOR VERIFICATION: Candidate has $tab_label of $tool open in Safari during the examination."
      fi
    done
  fi
fi

# ==============================================================================
# 4. APPLICATIONS LAUNCHED DURING THE ASSESSMENT WINDOW
# ==============================================================================
hdr "4. AI & REMOTE APPLICATIONS LAUNCHED IN TEST WINDOW"

while IFS= read -r app_path; do
  [ -n "$app_path" ] || continue
  case "$app_path" in
    /System/Library/*|*/antigravity/*|*/.gemini/*) continue ;;
    /System/*)
      if ! echo "$app_path" | grep -iEq 'Screen Sharing'; then
        continue
      fi
      ;;
  esac
  app_name=$(basename "$app_path" .app)
  
  # Suppress duplicate if application is already recorded as running
  grep -qiE "Running:.*$app_name" "$PROOF_F" 2>/dev/null && continue
  
  if echo "$app_name $app_path" | grep -iEq "$AI"; then
    lused=$(mdls -name kMDItemLastUsedDate -raw "$app_path" 2>/dev/null | cut -d'.' -f1)
    
    app_meaning="PROCTOR VERIFICATION: AI coding assistant or interview evasion tool ($app_name) was launched during the exam window. Used to automatically scrape problems and generate solutions."
    
    record_proof "RECENT APPLICATION" \
      "AI Cheat Tool Launched: $app_name" \
      "Path: $app_path | Last Launched: $lused" \
      "$app_meaning"
  fi
done < <(mdfind "kMDItemContentType == 'com.apple.application-bundle' && kMDItemLastUsedDate >= \$time.now(-$SECS)" 2>/dev/null)

# ==============================================================================
# 5. DEEP BROWSER HISTORY & EXACT AI CHAT TIMELINE
# ==============================================================================
hdr "5. DEEP BROWSER HISTORY & EXACT AI CHAT TIMELINE"

NOW=$(date +%s)
CCUT=$(( (NOW - SECS + 11644473600) * 1000000 ))   # Chromium microseconds since 1601
SCUT=$(( NOW - SECS - 978307200 ))                 # Safari seconds since 2001
FCUT=$(( (NOW - SECS) * 1000000 ))                 # Firefox microseconds since 1970

# Chromium Browsers (All Profiles Across Chrome, Brave, Edge, Arc, Opera, Vivaldi, Comet, etc.)
find "$HOME/Library/Application Support" -maxdepth 4 -name "History" -type f 2>/dev/null | grep -iE 'Google/Chrome|BraveSoftware|Microsoft Edge|Arc|Vivaldi|operasoftware|Chromium|Comet|Yandex' | while IFS= read -r hpath; do
  [ -f "$hpath" ] || continue
  P=$(dirname "$hpath")
  
  b_clean="Chromium"
  prof_name=$(basename "$P")
  case "$hpath" in
    *Google/Chrome*) b_clean="Chrome" ;;
    *BraveSoftware*) b_clean="Brave" ;;
    *Microsoft\ Edge*) b_clean="Edge" ;;
    *Arc*) b_clean="Arc" ;;
    *Vivaldi*) b_clean="Vivaldi" ;;
    *Opera*|*operasoftware*) b_clean="Opera"; prof_name="Default" ;;
    *Comet*) b_clean="Comet" ;;
    *Chromium*) b_clean="Chromium" ;;
    *Yandex*) b_clean="Yandex" ;;
  esac
  
  td=$(mktemp -d)
  cp "$P/History"* "$td/" 2>/dev/null
  cp "$P/Shortcuts"* "$td/" 2>/dev/null
  cp "$P/Web Data"* "$td/" 2>/dev/null
  
  # Extract logged-in account email for this profile
  prof_account="Default Account"
  if [ -f "$P/Preferences" ]; then
    pa=$(python3 -c "
import json
try:
    with open('$P/Preferences', 'r') as f:
        d = json.load(f)
        accs = d.get('account_info', [])
        if accs and accs[0].get('email'):
            print(accs[0]['email'])
except: pass
" 2>/dev/null)
    [ -n "$pa" ] && prof_account="$pa"
  fi
  if [ "$prof_account" = "Default Account" ] && [ -f "$td/Web Data" ]; then
    pa=$(sqlite3 "$td/Web Data" "SELECT value FROM autofill WHERE (name LIKE '%email%' OR name LIKE '%login%') AND value LIKE '%@%' ORDER BY count DESC LIMIT 1;" 2>/dev/null)
    [ -n "$pa" ] && prof_account="$pa"
  fi
  
  # 1. Query active visits in History database
  while IFS=$'\t' read -r vtime dur url title epoch oguid; do
    [ -n "$url" ] || continue
    is_garbage_url "$url" && continue
    
    is_match=0
    if echo "$url" | grep -iEq "$DOMAINS"; then
      is_match=1
    elif echo "$url" | grep -iEq '^https?://(www\.)?(google|bing)\.com/search' && echo "$url $title" | grep -iEq "$SEARCH_CHEAT"; then
      is_match=1
    fi
    
    if [ "$is_match" -eq 1 ]; then
      tool=$(tool_of "$url")
      dev_tag="Local Laptop"
      if [ -n "$oguid" ]; then
        dev_tag="Mobile Phone / Synced Device (ID: $oguid)"
      fi
      # Columns: vtime, dur, url, title, epoch, browser, profile, tool, dev_tag, prof_account
      echo "$vtime	$dur	$url	$title	$epoch	$b_clean	$prof_name	$tool	$dev_tag	$prof_account" >> "$TIMELINE_F"
    fi
  done < <(sqlite3 -readonly -separator $'\t' "$td/History" "SELECT datetime(v.visit_time/1000000-11644473600, 'unixepoch', 'localtime'), coalesce(v.visit_duration/1000000, 0), u.url, replace(replace(coalesce(u.title, ''), char(10), ' '), char(13), ' '), cast(v.visit_time/1000000-11644473600 as integer), coalesce(v.originator_cache_guid, '') FROM visits v JOIN urls u ON u.id=v.url WHERE v.visit_time > $CCUT ORDER BY v.visit_time ASC" 2>/dev/null)
  
  # 2. Check for Deleted URLs in Shortcuts Cache (Omnibox Autocomplete)
  if [ -f "$td/Shortcuts" ]; then
    short_urls=""
    short_cnt=0
    short_stool=""
    while IFS=$'\t' read -r stext surl stime sepoch; do
      [ -n "$surl" ] || continue
      is_garbage_url "$surl" && continue
      
      if echo "$surl" | grep -iEq "$DOMAINS"; then
        stool=$(tool_of "$surl")
        short_stool="$stool"
        in_act=$(sqlite3 -readonly "$td/History" "SELECT count(*) FROM visits v JOIN urls u ON u.id=v.url WHERE u.url = '$surl' AND v.visit_time > $CCUT;" 2>/dev/null || echo 0)
        if [ "$in_act" -eq 0 ]; then
          short_cnt=$((short_cnt + 1))
          if [ -z "$short_urls" ]; then
            short_urls="$surl"
          else
            short_urls="$short_urls | $surl"
          fi
          echo "$stime	0	$surl	[DELETED HISTORY] $stool	$sepoch	$b_clean	$prof_name	$stool	Local Laptop	$prof_account" >> "$TIMELINE_F"
        fi
      fi
    done < <(sqlite3 -readonly -separator $'\t' "$td/Shortcuts" "SELECT replace(replace(text, char(10), ' '), char(13), ' '), replace(replace(url, char(10), ' '), char(13), ' '), datetime(last_access_time/1000000-11644473600, 'unixepoch', 'localtime'), cast(last_access_time/1000000-11644473600 as integer) FROM omni_box_shortcuts WHERE last_access_time > $CCUT;" 2>/dev/null)
    
    if [ "$short_cnt" -gt 0 ]; then
      record_proof "TAMPERING / DELETION" \
        "Deleted $short_stool History Recovered in $b_clean (Account: $prof_account)" \
        "Candidate visited $short_stool ($short_cnt URLs recovered from Omnibox shortcut cache: $short_urls)." \
        "PROCTOR VERIFICATION: Candidate opened this AI tool during the exam and then deleted browsing history to hide it. The URLs were forensically recovered from the browser shortcut cache."
    fi
  fi
  
  rm -rf "$td"
done

# Safari
if [ -f "$HOME/Library/Safari/History.db" ]; then
  td=$(mktemp -d); cp "$HOME/Library/Safari/History.db"* "$td/" 2>/dev/null
  if [ -f "$td/History.db" ]; then
    while IFS=$'\t' read -r vtime dur url title epoch; do
      [ -n "$url" ] || continue
      is_garbage_url "$url" && continue
      if echo "$url" | grep -iEq "$DOMAINS"; then
        tool=$(tool_of "$url")
        echo "$vtime	0	$url	$title	$epoch	Safari	Default	$tool" >> "$TIMELINE_F"
      fi
    done < <(sqlite3 -readonly -separator $'\t' "$td/History.db" "SELECT datetime(hv.visit_time + 978307200, 'unixepoch', 'localtime'), 0, hi.url, coalesce(hi.title, ''), cast(hv.visit_time + 978307200 as integer) FROM history_visits hv JOIN history_items hi ON hi.id=hv.history_item WHERE hv.visit_time > $SCUT ORDER BY hv.visit_time ASC" 2>/dev/null)
  fi
  rm -rf "$td"
fi

# Firefox
for FP in "$HOME/Library/Application Support/Firefox/Profiles"/*/places.sqlite; do
  [ -f "$FP" ] || continue
  prof_name=$(basename "$(dirname "$FP")")
  td=$(mktemp -d); cp "$FP"* "$td/" 2>/dev/null
  while IFS=$'\t' read -r vtime dur url title epoch; do
    [ -n "$url" ] || continue
    is_garbage_url "$url" && continue
    if echo "$url" | grep -iEq "$DOMAINS"; then
      tool=$(tool_of "$url")
      echo "$vtime	0	$url	$title	$epoch	Firefox	$prof_name	$tool" >> "$TIMELINE_F"
    fi
  done < <(sqlite3 -readonly -separator $'\t' "$td/places.sqlite" "SELECT datetime(v.visit_date/1000000, 'unixepoch', 'localtime'), 0, p.url, replace(replace(coalesce(p.title, ''), char(10), ' '), char(13), ' '), cast(v.visit_date/1000000 as integer) FROM moz_historyvisits v JOIN moz_places p ON p.id=v.place_id WHERE v.visit_date > $FCUT ORDER BY v.visit_date ASC" 2>/dev/null)
  rm -rf "$td"
done

# Sort timeline by epoch timestamp
if [ -s "$TIMELINE_F" ]; then
  sort -t$'\t' -k5,5n "$TIMELINE_F" -o "$TIMELINE_F"
  
  # Session summary aggregation: record high-level proof for distinct tools
  awk -F'\t' '
  {
    dev = $9
    if (dev == "") dev = "Local Laptop"
    acc = $10
    if (acc == "") acc = "Primary Account"
    key = $8 " in " $6 " (Account: " acc ", " dev ")"
    count[key]++
    if (!first[key]) { first[key] = $1 }
    last[key] = $1
    dur[key] += $2
  }
  END {
    for (k in count) {
      d = dur[k]
      dm = int(d / 60); ds = d % 60
      if (first[k] == last[k]) {
        span = "at " first[k]
      } else {
        span = "from " first[k] " to " last[k]
      }
      printf "%s\t%s\t%d visits\tactive: %dm %ds\n", k, span, count[k], dm, ds
    }
  }' "$TIMELINE_F" | while IFS=$'\t' read -r k span cnt dstr; do
    record_proof "AI CHAT / BROWSER HISTORY" \
      "$k was opened $span ($cnt, $dstr)" \
      "History database record confirmed during OA window." \
      "PROCTOR VERIFICATION: Candidate opened and engaged with this AI/solver tool during the assessment."
  done
fi

# ==============================================================================
# AUDIT VERDICT & EVIDENCE DOSSIER
# ==============================================================================
say ""
say "========================================================================"
if [ -s "$PROOF_F" ]; then
  num_proofs=$(grep -c "^CATEGORY|" "$PROOF_F")
  say "  ${CLR_B}${CLR_R}PROCTOR VERDICT: ⚠️ CHEATING / EVASION DETECTED ($num_proofs violation items)${CLR_N}"
  say "  Candidate Computer: $(scutil --get ComputerName 2>/dev/null || hostname)   |   User: $(whoami)"
  say "  Audit Lookback: Last $HOURS hour(s)   |   Verified: $(date '+%Y-%m-%d %H:%M:%S')"
  say ""
  say "  ${CLR_B}INVIGILATOR 5-SECOND CHECKLIST:${CLR_N}"
  if grep -q "CATEGORY|SCREEN MIRRORING" "$PROOF_F" || grep -qiE "Screen Sharing|VNC" "$PROOF_F"; then
    say "    ${CLR_R}[!] Screen Mirroring / Remote Sharing : DETECTED (Screen Sharing/VNC)${CLR_N}"
  else
    say "    ${CLR_G}[✓] Screen Mirroring / Display Cloning : Clean${CLR_N}"
  fi
  if grep -q "CATEGORY|REMOTE ACCESS" "$PROOF_F"; then
    rd_tools=""
    grep -qi "AnyDesk" "$PROOF_F" && rd_tools="AnyDesk"
    grep -qi "TeamViewer" "$PROOF_F" && rd_tools="${rd_tools:+$rd_tools/}TeamViewer"
    grep -qi "RustDesk" "$PROOF_F" && rd_tools="${rd_tools:+$rd_tools/}RustDesk"
    grep -qiE "Screen Sharing|VNC" "$PROOF_F" && rd_tools="${rd_tools:+$rd_tools/}VNC/ScreenSharing"
    [ -z "$rd_tools" ] && rd_tools="Active Tool"
    say "    ${CLR_R}[!] Remote Screen Share / Control Session : DETECTED ($rd_tools)${CLR_N}"
  else
    say "    ${CLR_G}[✓] Remote Screen Share / Control Session : Clean${CLR_N}"
  fi
  if grep -q "CATEGORY|LIVE OPEN TAB" "$PROOF_F"; then
    say "    ${CLR_R}[!] Live AI Tabs Open Right Now       : DETECTED (Gemini/ChatGPT)${CLR_N}"
  else
    say "    ${CLR_G}[✓] Live AI Tabs Open Right Now       : Clean${CLR_N}"
  fi
  if grep -q "CATEGORY|AI CHAT / BROWSER HISTORY" "$PROOF_F"; then
    say "    ${CLR_R}[!] AI Website / Solver Visited        : DETECTED${CLR_N}"
  else
    say "    ${CLR_G}[✓] AI Website / Solver Visited        : Clean${CLR_N}"
  fi
  if grep -q "CATEGORY|TAMPERING / DELETION" "$PROOF_F"; then
    say "    ${CLR_R}[!] Browser History Wiped / Tampered   : DETECTED (Recovered from shortcut cache)${CLR_N}"
  else
    say "    ${CLR_G}[✓] Browser History Wiped / Tampered   : Clean${CLR_N}"
  fi
  say "========================================================================"
  
  idx=1
  curr_cat=""
  curr_title=""
  curr_details=""
  curr_meaning=""
  
  while IFS='|' read -r k v; do
    case "$k" in
      CATEGORY) curr_cat="$v" ;;
      TITLE) curr_title="$v" ;;
      DETAILS) curr_details="$v" ;;
      MEANING) curr_meaning="$v" ;;
      "---")
        say ""
        say "  ${CLR_B}${CLR_R}[PROOF #$idx] $curr_cat: $curr_title${CLR_N}"
        say "    ${CLR_C}Evidence:${CLR_N} $curr_details"
        say "    ${CLR_Y}Proctor Meaning:${CLR_N} $curr_meaning"
        idx=$((idx + 1))
        ;;
    esac
  done < "$PROOF_F"

else
  say "  ${CLR_B}${CLR_G}PROCTOR VERDICT: ✅ CLEAN - NO CHEATING DETECTED${CLR_N}"
  say "  Candidate Computer: $(scutil --get ComputerName 2>/dev/null || hostname)   |   User: $(whoami)"
  say "  Audit Lookback: Last $HOURS hour(s)   |   Verified: $(date '+%Y-%m-%d %H:%M:%S')"
  say ""
  say "  ${CLR_B}INVIGILATOR 5-SECOND CHECKLIST:${CLR_N}"
  say "    ${CLR_G}[✓] Screen Mirroring / Display Cloning : Clean${CLR_N}"
  say "    ${CLR_G}[✓] Remote Screen Share / Control Session : Clean${CLR_N}"
  say "    ${CLR_G}[✓] Live AI Tabs Open Right Now       : Clean${CLR_N}"
  say "    ${CLR_G}[✓] AI Website / Solver Visited        : Clean${CLR_N}"
  say "    ${CLR_G}[✓] Browser History Wiped / Tampered   : Clean${CLR_N}"
  say "========================================================================"
fi

# ==============================================================================
# CONSOLIDATED AI ACTIVITY WINDOWS (Merged Session Timeline)
# ==============================================================================
if [ -s "$TIMELINE_F" ]; then
  say ""
  say "========================================================================"
  say "  ${CLR_B}${CLR_C}CONSOLIDATED AI & CHEATING TIMELINE (MERGED WINDOWS)${CLR_N}"
  say "========================================================================"
  
  # Group consecutive visits into distinct windows using 5-minute (300s) threshold
  awk -F'\t' '
  BEGIN {
    session_gap = 300
    s_idx = 0
  }
  {
    vtime = $1
    dur = $2 + 0
    url = $3
    title = $4
    epoch = $5 + 0
    browser = $6
    prof = $7
    tool = $8
    dev = $9
    if (dev == "") dev = "Local Laptop"
    acc = $10
    if (acc == "") acc = "Primary Account"

    key = tool "|||" browser "|||" prof "|||" dev "|||" acc

    if (key != curr_key || (epoch - last_epoch > session_gap && last_epoch > 0)) {
      if (curr_key != "") {
        print_window()
      }
      curr_key = key
      s_tool = tool
      s_browser = browser
      s_prof = prof
      s_dev = dev
      s_acc = acc
      s_start = vtime
      s_dur = 0
      s_count = 0
      delete s_urls
    }

    s_end = vtime
    s_dur += dur
    s_count++
    last_epoch = epoch
    s_urls[url] = title
  }
  END {
    if (curr_key != "") {
      print_window()
    }
  }

  function print_window() {
    s_idx++
    dm = int(s_dur / 60)
    ds = s_dur % 60
    
    if (s_start == s_end) {
      span = "at " s_start
    } else {
      span = "from " s_start " to " s_end
    }
    
    printf "\n  \033[1m\033[31m[WINDOW #%d] %s in %s (Profile: %s)\033[0m\n", s_idx, s_tool, s_browser, s_prof
    printf "    • \033[36mAccount Used\033[0m  : \033[33m%s\033[0m\n", s_acc
    printf "    • \033[36mDevice Origin\033[0m : %s\n", s_dev
    printf "    • \033[36mTime Window\033[0m   : %s\n", span
    printf "    • \033[36mInteractions\033[0m  : %d visits (total recorded active dwell time: %dm %ds)\n", s_count, dm, ds
    printf "    • \033[36mSpecific Chat / Problem URLs Accessed:\033[0m\n"
    for (u in s_urls) {
      tit = s_urls[u]
      if (tit != "") tit = " - \"" tit "\""
      printf "        \033[33m-\033[0m %s%s\n", u, tit
    }
  }' "$TIMELINE_F" >&3
fi

say ""
say "========================================================================"
say "  AUDIT COMPLETE: All evidence presented is verified against local system records."
say "========================================================================"
say ""

rm -f "$PROOF_F" "$TIMELINE_F" "$APPSF"

if [ -t 0 ] || [ -c /dev/tty ]; then
  printf "\033[1;36mAudit complete. Press [Enter] to exit...\033[0m " >&3
  read -r _ </dev/tty 2>/dev/null || true
fi
